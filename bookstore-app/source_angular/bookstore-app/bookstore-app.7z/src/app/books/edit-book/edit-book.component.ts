import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { BooksService } from "../books.services";


@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent implements OnInit {

  constructor(private _bookService: BooksService, private route: ActivatedRoute, private router: Router) { }
book:any;
id:any;

genre_arr=["fiction","thriller","mystery","comic"];
 format_arr=["paperback","e-book","hardcover","audio-book"]; 

  ngOnInit(): void {
      this.route.params.forEach((params: Params) => {
          this.id = +params['id'];
      });
  
      for (let i = 0; i < this._bookService.book_list.length; i++) {
      if (this._bookService.book_list[i].id == this.id) {
this.book=this._bookService.book_list[i];
  }
      }
      console.log(this.book);
  }
onSubmit(formValue){
this.book.title=formValue.title;
this.book.author=formValue.author;
this.book.price=formValue.price;
this.book.genre=formValue.genre;
this.book.format=formValue.format;


      for (let i = 0; i < this._bookService.book_list.length; i++) {
      if (this._bookService.book_list[i].id == this.id) {
this._bookService.book_list[i]=this.book;
  }
      }
this.router.navigate(['books']);
}
  }
