import {Injectable} from '@angular/core'

@Injectable()
export class BooksService{

book_list=[
{
    id:1,
    title:"Harry Potter",
    author:"JK Rowling",
    price:333,
    format:"Paperback",
    genre:"fiction"

},
{
    
    id:2,
    title:"And then there were none",
    author:"Agatha Christie",
    price:233,
    format:"Hardbound",
    genre:"Murder Mystery"
}
];

 getBookCount(){
return this.book_list.length;
 } 
}