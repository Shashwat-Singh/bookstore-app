import { Component, OnInit } from '@angular/core';
import { BooksService } from "./books.services";
@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

books:any[];
constructor(private _bookService: BooksService) { }
  ngOnInit() {
this.books=this._bookService.book_list; 
 }

Delete(id){
for (let i = 0; i < this._bookService.book_list.length; i++) {
      if (this._bookService.book_list[i].id == id) {
        this._bookService.book_list.splice(i, 1);
      }
    }
}

}
