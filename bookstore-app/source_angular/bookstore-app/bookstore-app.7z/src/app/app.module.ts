import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { routing }  from './app.routing';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { BooksComponent } from './books/books.component';
import { AddBooksComponent } from './books/add-books/add-books.component';
import { DeleteBooksComponent } from './books/delete-books/delete-books.component';
import { BooksService } from './books/books.services';
import { EditBookComponent } from './books/edit-book/edit-book.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    BooksComponent,
    AddBooksComponent,
    DeleteBooksComponent,
    EditBookComponent
  ],
  imports: [
    BrowserModule,routing,FormsModule
  ],
  providers: [ BooksService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
