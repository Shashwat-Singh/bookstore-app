import { Component, OnInit } from '@angular/core';
import { BooksService } from "../books.services";
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-add-books',
  templateUrl: './add-books.component.html',
  styleUrls: ['./add-books.component.css']
})
export class AddBooksComponent implements OnInit {

genre_arr=["fiction","thriller","mystery","comic"];
 format_arr=["paperback","e-book","hardcover","audio-book"];  
  constructor(private _bookService: BooksService, private router: Router) { }

  ngOnInit() {
  }

onSubmit(formValue){
  let bookCount = this._bookService.getBookCount();
let newBook = {
          id: bookCount + 1,
          title: formValue.title,
          author: formValue.author,
          price: formValue.price,
          genre: formValue.genre,
          format:formValue.format
        };
        console.log(newBook);
   this._bookService.book_list.push(newBook);
    this.router.navigate(['books']);
}
}
