import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-books',
  templateUrl: './delete-books.component.html',
  styleUrls: ['./delete-books.component.css']
})
export class DeleteBooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
